La forma de compilación usada por todos los integrantes del grupo fue a través de GCC
y utilizando WSL. 
Ya que en los 2 problemas contamos con 2 archivos con la extensión .c, tuvimos que compilar 
y ejecutar el programa de la siguiente manera:
Pregunta 1: gcc lista_enlazada.c problema_1.c -Wall -o problema_1 && ./problema_1
Pregunta 2: gcc abb.c problema_2.c -Wall -o problema_2 && ./problema_2