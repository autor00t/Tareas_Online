La forma de compilación usada por todos los integrantes del grupo fue a través de GCC
y utilizando WSL. 
Debido a que contabamos con varios archivos .c, para compilar y ejecutar usabamos el comando:
gcc heap.c oferta.c producto.c main.c -Wall -o main && ./main